<?php

function has_presence($val)
{
	return isset($val) && $val!=="";
}

function has_max_len($val,$max)
{
	return strlen($val)<= $max;
}

function has_inclusion_in($value,$set)
{
	return in_array($value,$set);
}

function max_len($field_with_max_len)
{
	foreach($field_with_max_len as $field => $max)
	{
		$value=trim($_POST[$field]);
		if(!has_max_len($value,$max))
		{
			global $errors;
			$errors[$field]=ucfirst($field)." is too long.";
		}
	}
}

function form_errors($errors=array())
{
	$output="";
	if(!empty($errors))
	{
		$output.="Please fix the following errors: <br>";
			$output.="<div> <ul>";
		foreach($errors as $key => $error)
		{
			$output.="<li>".$error."</li>";
		}
		$output.="</ul> </div>";
	}
	return $output;
}



?>