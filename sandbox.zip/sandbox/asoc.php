<html>
<head>
<title>
Associative Arrays
</title>
</head>
<body>
<?php $assoc=array("f_name"=>"kevin","l_name"=>"luther"); ?>
<?php echo $assoc["f_name"]; ?><br>
<?php $assoc["f_name"]="larry";?>
<?php echo $assoc["f_name"]; ?>
<?php //echo $assoc[0];?>
<br>
<?php $num=array(8,23,15,42,16,4); ?>
count: <?php echo count($num); ?><br>
max: <?php echo max($num); ?><br>
min: <?php echo min($num); ?><br>
sort: <?php sort($num); print_r($num); ?><br>
rsort: <?php rsort($num); print_r($num); ?>

</body>
</html>