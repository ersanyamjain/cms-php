<html>
<head>
<title>
Int
</title>
</head>
<body>
<?php
$var1=3; $var2=4; ?>
Basic Math: <?php ((1+2+$var1)*$var2)/2-5; ?>
<br>
ABs Value: <?php echo abs(0-300); ?><br>
Expo: <?php echo pow(2,8); ?><br>
Sqr Root: <?php echo sqrt(100); ?><br>
Modulo: <?php echo fmod(20,7); ?><br>
Random: <?php echo rand(); ?><br>
Ran Min Max: <?php echo rand(1,10); ?><br>
Inc: <?php $var2+=4; echo $var2;
?>
</body>
</html>