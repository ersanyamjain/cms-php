<?php

function hello($name,$greet,$punc)
{
	return $greet." ".$name." ".$punc;
}

function red_to($new_loc)
{
	header("Location: ".$new_loc);
	exit;
}

?>