<html>
<head>
<title>
Second Page
</title>
</head>
<body>
<?php 

$company=$_GET['company'];
echo $company; ?>


</body>
</html>