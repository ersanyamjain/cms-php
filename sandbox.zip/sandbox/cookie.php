<?php

$name="test";
$value="48";
$expire=time()+3600;
//setcookie($name,$value,$expire);
//setcookie($name);
//setcookie($name,$value,$expire);
//setcookie($name,null);
//setcookie($name,$value,$expire);
setcookie($name,$value,time()-3600);
?>
<html>
<head>
<title>
Cookies
</title>
</head>
<body>

<?php

// print_r($_COOKIE);
if(isset($_COOKIE["test"])){
	
$test=$_COOKIE["test"];
}
else { $test=""; }
	echo $test;
 ?>

</body>
</html>