<?php

//session_start();

?>
<html>
<head>
<title>
Sessions
</title>
</head>
<body>
<?php
$_SESSION['first_name']="Sam";
$name=$_SESSION['first_name'];
echo $name;

?>
</body>
</html>