<html>
<head>
<title>
Validation
</title>
</head>
<body>
<?php
$value="";
//presence
if(!isset($value) || empty($value))
{
	echo "1 Validation failed <br>";
}

//length
$value="";
$min=3;
$max=10;
if(strlen($value)<$min || strlen($value)>$max)
{
echo "2 Validation failed <br>";
}

//type
$value="";
if(!is_int($value))
{
	echo "3 Validation failed <br>";
}

//inclusion in a set
$value="5";
$set=array("1","2","3","4");
if(!in_array($value,$set))
{
	echo "4 Validation failed <br>";
}

//uniqueness - With Databases

//format
if(preg_match("/PHP/","PHP is fun."))
{
	echo "A match is found <br>";
	
} else { echo "5 Match not found <br>";}

$value="nobody@xyz.com";
if(!preg_match("/@/",$value))
{
	 echo "6 Match not found <br>";
	
}
$value="@xyz.com";
if(strpos($value,"@")===false) //strictly equals to
{
	 echo "7 Validation Failed <br>";
}
?>
</body>
</html>