<html>
<head>
<title>
Default Arguments
</title>
</head>
<body>
<?php

function paint($color="red",$room="office")
{
	return "The color of {$room} is {$color}"."<br>";
}
echo paint();
echo paint("blue","bedroom");
echo paint(null,"bedroom");
echo paint("blue");
echo paint("bedroom");

?>
</body>
</html>