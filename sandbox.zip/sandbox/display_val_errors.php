<?php

require_once("validation_func.php");

?>
<html>
<head>
<title>
Errors
</title>
</head>
<body>
<pre><?php 
$value=trim("");
$errors=array();
if(!isset($value)||$value==="")
{
$errors['value']="Value can't be blank";	
}
echo form_errors($errors);
?> </pre>
</body>
</html>