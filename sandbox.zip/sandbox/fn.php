<html>
<head>
<title>
Functions
</title>
</head>
<body>
<?php 

function c_z($year)
{
	switch(($year-4)%12)
	{
		case 0: return 'Rat';
		case 1: return 'Ox';
		case 2: return '2';
default: return $year;	
	}
}
$zod = c_z(2013);
echo "2013 is an year of {$zod}.<br>";
echo "2013 is an year of ".c_z(2018)."<br>";
 	

?>

<br>

<?php

/*function add_sub($val1,$val2)
{
	$add=$val1+$val2;
	$sub=$val1-$val2;
	return array($add,$sub);
}
$res=add_sub(10,5);
echo "Add: ".$res[0]."<br>";
echo "Sub: ".$res[1]."<br>"; */
?>



<?php

 /* function add_sub($val1,$val2)
{
	$add=$val1+$val2;
	$sub=$val1-$val2;
	return array($add,$sub);
}
list($addr,$subr)=add_sub(10,5);
echo "Add: {$addr}"."<br>";
echo "Sub: {$subr}"."<br>"; */
?>



</body>
</html>