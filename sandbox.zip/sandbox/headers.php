<?php 
header("HTTP 1.1/ 4040 Not Found");
header("X-Powered By: Primia Tech");

?>
<html>
<head>
<title>
Header
</title>
</head>
<body>
<pre>
<?php print_r(headers_list()); ?>
</pre>
</body>
</html>