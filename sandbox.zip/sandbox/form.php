<html>
<head>
<title>
Form
</title>
</head>
<body>
<form action="form_processing.php" method="post">
Username: <input type="text" name="username" value=""><br>
Password: <input type="password" name="password" value=""><br>
<br><input type="submit" name="submit" value="Submit">
</form>
 
</body>
</html>