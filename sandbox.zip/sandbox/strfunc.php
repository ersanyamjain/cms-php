<html>
<head>
<title>
Sting Functions
</title>
</head>
<body>
<?php 
$f="The quick brown";
$s="fox jumps over";
$th=$f;
$th.=$s;
echo $th."<BR>";
LC: echo strtolower($th)."<BR>";
UC: echo strtoupper($th)."<BR>";
UCF: echo ucfirst($th)."<BR>";
UCW: echo ucwords($th)."<BR>";
Ln: echo strlen($th)."<BR>";
Trim: echo "A".trim("   B C D ")."E"."<BR>";
Find: echo strstr($th,"brown")."<BR>";
Replace : echo str_replace("quick","super-fast",$th)."<BR>";
Repeat: echo str_repeat($th,2)."<BR>";
Substr: echo substr($th,2,8)."<BR>";
FindPos: echo strpos($th,"brown")."<BR>";
FindChar: echo strchr($th,"b")."<BR>";
?>

</body>
</html>