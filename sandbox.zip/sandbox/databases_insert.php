<?php
$dbhost="localhost";
$dbuser="primia_cms";
$dbpass="secret";
$dbname="primia_tech";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno())
{
	die("Database Connection Failed: ".mysqli_connect_error()."(".mysqli_connect_errno().")");
}
?>

<?php
$menu_name="Edit me";
$menu_name=mysqli_real_escape_string($connection,$menu_name);
$position=4;
$visible=1;
$query="insert into subjects(menu_name,position,visible) values('{$menu_name}',{$position},{$visible})";
$result = mysqli_query($connection,$query);
if(!$result)
{
	die("Database Query Failed".mysqli_error($connection));
}
else
{
	echo "Success!";
}
?>
<html>
<head>
<title>
Databases
</title>
</head>
<body>
</body>
</html>

<?php
mysqli_close($connection);
?>