<?php 
require_once("included_func.php");
require_once("validation_func.php");

$errors=array();
$message="Please Log in";

if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	$fields_required=array("username","password");
	foreach($fields_required as $field)
	{
		$value=trim($_POST[$field]);
		if(!has_presence($value))
		{
			$errors[$field]=ucfirst($field)." can't be blank.";
		}
	}
	
	$field_with_max_len=array("username"=>20,"password"=>8);
	validate_max_len($field_with_max_len);
	if(empty($errors))
	{
		if($username=="admin" && $password=="admin"){
	//successful login
	red_to("basic.html");
		}
		else
		{
	$message="Username/Password do not match. <br>";
		}			
	}
}
		else
	{
		$username="";
		$message="Please Log in";
	}

?>
<html>
<head>
<title>
Single Page Form Processing
</title>
</head>
<body>

<?php echo form_errors($errors); ?>
<?php echo $message;?><br>
<form action="form_with_validations.php" method="post">
Username: <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>"><br>
Password: <input type="password" name="password" value=""><br>
<br><input type="submit" name="submit" value="Submit">
</form>
 
</body>
</html>
