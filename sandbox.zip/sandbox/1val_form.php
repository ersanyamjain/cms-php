<?php
require_once("1inc_func.php");
require_once("1val_func.php");

$errors=array();
$message="Please Log In";

if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	$fields_req=array("username","password");
	
	foreach($_POST as $check=>$value)
	{
	if(!has_presence(trim($value)))
	{
		$errors[$check]=ucfirst($check)." can't be blank.";
	}
	}
	
	$fields_with_max_len=array("username"=>20,"password"=>8);
	max_len($fields_with_max_len);
	
	if(empty($errors))
	{
	
	if($username=="admin" && $password=="admin")
	{
		//Successful Login
		red_to("basic.html");
	}
	else
	{
			$message="Username/Password do not match.<br>";
	}
}

}
else
{
	$message="Please Log In";
		$username="";
}

?>
<html>
<head>
<title>
Form Validation
</title>
</head>
<body>
<?php echo form_errors($errors); ?>
<?php echo $message; ?>
<form action="1val_form.php" method="post">
Username: <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>"><br>
Password: <input type="password" name="password" value=""><br><br>
<input type="submit" name="submit" value="Submit">
</form>
</body>
</html>