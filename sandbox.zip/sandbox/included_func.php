<?php function hello($name)
{
return "Hello {$name} !";

}
 
function red_to($new_loc)
{
	header("Location: ".$new_loc);
	exit;
}
/*function form_errors($errors=array())
{
	$output="";
	if(!empty ($errors))
	{
		$output="<div class\"errors\">";
		$output.="Please fix the following errors:";
		$output.="<ul>";
		foreach($errors as $key => $error){
			$output.="<li>{$error}</li>";
		}
		$output.="</ul>";
		$output.="</div>";
	}
	return $output;
}
*/
?>