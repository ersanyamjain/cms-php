<html>
<head>
<title>
HelloWorld
</title>
</head>
<body>
<?php echo "Hello World!"; ?><br />
<?php echo "Hello"." World!"; ?><br />
<?php echo 5+9*2 ?>
<?php 
//Single line
/* Multi
Line
Comments
*/
#Single line
 ?><br />
</body>
</html>