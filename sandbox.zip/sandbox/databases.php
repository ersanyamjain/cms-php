<?php
$dbhost="localhost";
$dbuser="primia_cms";
$dbpass="secret";
$dbname="primia_tech";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno())
{
	die("Database Connection Failed: ".mysqli_connect_error()."(".mysqli_connect_errno().")");
}
?>

<?php
$query="select * from subjects where visible=1";
$result = mysqli_query($connection,$query);
if(!$result)
{
	die("Database Query Failed");
}

?>
<html>
<head>
<title>
Databases
</title>
</head>
<body>
<?php /*
//while($row=mysqli_fetch_row($result))
	//while($row=mysqli_fetch_assoc($result))
		//while($row=mysqli_fetch_array($result))
while($row=mysqli_fetch_array($result,MYSQL_ASSOC))
{
	var_dump($row);
	echo "<hr>";
}
*/
?>
<?php
/*
while($row=mysqli_fetch_array($result,MYSQL_ASSOC))
{
	echo $row["id"]."<br>";
	echo $row["menu_name"]."<br>";
	echo $row["position"]."<br>";
	echo $row["visible"]."<br>"; 
	echo "<hr>";
}
*/
	?> 
	
	<ul>
	<?php while($subjects=mysqli_fetch_assoc($result))
	{
		?>
		<li> <?php echo $subjects["menu_name"]."(".$subjects["id"].")"; ?> </li>
	<?php 
}
?>
</ul>
</body>
</html>
<?php
mysqli_free_result($result);
?>
<?php
mysqli_close($connection);
?>