<?php 
function red_to($new_loc)
{
header("Location: ".$new_loc);
exit;	
}
$logged_in=$_GET['logged_in'];
if($logged_in=="1")
	red_to("basic.html");
else
	red_to("http://www.google.com");

?>

<html>
<head>
<title>
Redirect
</title>
</head>
<body>

</body>
</html>