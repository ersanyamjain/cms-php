<?php
$dbhost="localhost";
$dbuser="primia_cms";
$dbpass="secret";
$dbname="primia_tech";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno())
{
	die("Database Connection Failed: ".mysqli_connect_error()."(".mysqli_connect_errno().")");
}
?>

<?php
$menu_name="Delete me";
$position=4;
$visible=1;
$id=4;
$query="update subjects set ";
$query.="menu_name='{$menu_name}',";
$query.="position={$position},";
$query.="visible={$visible} ";
$query.="where id={$id}";
//echo $query."<br>";
$result = mysqli_query($connection,$query);
if($result && mysqli_affected_rows($connection)==1)
{
	echo "Success!";
	}
else
{
	die("Database Query Failed".mysqli_error($connection));
}
?>
<html>
<head>
<title>
Databases
</title>
</head>
<body>
</body>
</html>

<?php
mysqli_close($connection);
?>