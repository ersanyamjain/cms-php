<html>
<head>
<title>
Arrays
</title>
</head>
<body>
<?php
$num=array(4,8,15,16,23,43);
echo $num[1];
?>
<?php $mix=array(6,"fox","dog",array("x","y","z")); ?>
<?php echo $mix[2]; ?><br>
<?php //echo $mix[3]; ?><br>
<pre>
<?php echo print_r($mix); ?>
</pre>
<?php echo$mix[3][1]; ?>
<br>
<?php print_r($array=[1,2,3]); ?>

</body>
</html>