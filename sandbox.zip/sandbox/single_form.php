<?php 
require_once("included_func.php");
if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
if($username=="admin" && $password=="admin"){
	//successful login
	red_to("basic.html");
}
else
{
	$message="There are some errors";
}	
	}
	else
	{
		$username="";
		$message="Please Log in";
	}
?>
<html>
<head>
<title>
Single Page Form Processing
</title>
</head>
<body>
<?php echo $message; ?><br>

<form action="single_form.php" method="post">
Username: <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>"><br>
Password: <input type="password" name="password" value=""><br>
<br><input type="submit" name="submit" value="Submit">
</form>
 
</body>
</html>