<html>
<head>
<title>
Scopes
</title>
</head>
<body>

<?php 
/*
$bar="outside";
function foo()
{
	$bar="inside";
}	
echo "1:" .$bar."<br>";
foo();
echo "2:" .$bar."<br>";

*/
?>


<?php 
/*
$bar="outside";
function foo($bar)
{ 

if(isset($bar))
	echo "foo: ".$bar."<br>";
	 $bar="inside";
}	
echo "1:" .$bar."<br>";
foo($bar);
echo "2:" .$bar."<br>";

*/
?>


<?php 

$bar="outside";
function foo($bar)
{ 
global $bar;
if(isset($bar))
	echo "foo: ".$bar."<br>";
	 $bar="inside";
}	
echo "1:" .$bar."<br>";
foo($bar);
echo "2:" .$bar."<br>";


?>
</body>
</html>