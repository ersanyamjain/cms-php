<html>
<head>
<title>
ForEach
</title>
</head>
<body>

<?php 
$person=array("f_name"=>"Kevin","l_name"=>"Clein","Add"=>"Hill Street");
foreach ($person as $attrib=>$data)
{
	$att=ucwords(str_replace("_"," ",$attrib));
echo"{$att} - {$data}<br>"; 
	
}
?>
</body>
</html>