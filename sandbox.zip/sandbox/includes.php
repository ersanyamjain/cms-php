<?php

include("included_func.php");
include("included_header.php");
//require("included_func.php");
//require_once("included_func.php");
?>
Files have been included 
<br>
<?php echo hello("Everyone"); ?>
<br>
</body>
</html>