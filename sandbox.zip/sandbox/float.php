<html>
<head>
<title>
Floats
</title>
</head>
<body>
<?php echo $float=3.14; ?>
Round: <?php echo round($float,1); ?> <br>
Ceil: <?php echo ceil($float); ?> <br>
Floor: <?php echo floor($float); ?> <br>


</body>
</html>